/*
 * referee_processing_task.h
 *
 *  Created on: Jun 18, 2021
 *      Author: wx
 */

#ifndef TASKS_INC_REFEREE_PROCESSING_TASK_H_
#define TASKS_INC_REFEREE_PROCESSING_TASK_H_

void referee_processing_task(void *argument);

#endif /* TASKS_INC_REFEREE_PROCESSING_TASK_H_ */
