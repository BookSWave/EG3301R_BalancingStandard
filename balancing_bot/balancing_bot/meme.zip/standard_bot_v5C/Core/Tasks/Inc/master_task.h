/*
 * master_task.h
 *
 *  Created on: 14 Sep 2023
 *      Author: cwx
 */

#ifndef TASKS_INC_MASTER_TASK_H_
#define TASKS_INC_MASTER_TASK_H_


void master_task(void* argument);

#endif /* TASKS_INC_MASTER_TASK_H_ */
