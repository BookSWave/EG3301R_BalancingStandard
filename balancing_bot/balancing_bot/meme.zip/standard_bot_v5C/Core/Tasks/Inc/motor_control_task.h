/*
 * motor_control_task.h
 *
 *  Created on: Sep 26, 2023
 *      Author: wx
 */

#ifndef TASKS_INC_MOTOR_CONTROL_TASK_H_
#define TASKS_INC_MOTOR_CONTROL_TASK_H_

void motor_control_task(void *argument);
#endif /* TASKS_INC_MOTOR_CONTROL_TASK_H_ */
