/*
 * error_handler.c
 *
 *  Created on: Jan 9, 2022
 *      Author: wx
 */

//implement next time
