/*
 * movement_control_task.c
 *
 *  Created on: Jan 19, 2021
 *      Author: Hans Kurnia
 */

#include "board_lib.h"
#include "robot_config.h"
#include "motor_config.h"
#include "motor_control.h"
#include "arm_math.h"
#include "movement_control_task.h"

extern EventGroupHandle_t chassis_event_group;
extern chassis_control_t chassis_ctrl_data;

extern motor_data_t g_can_motors[24];
extern referee_limit_t g_referee_limiters;
extern ref_game_robot_data_t ref_robot_data;
extern speed_shift_t gear_speed;
float g_chassis_yaw = 0;
int32_t chassis_rpm = MAX_SPEED;
extern uint8_t g_gimbal_state;
extern uint8_t hall_state;

extern orientation_data_t imu_heading;
float motor_yaw_mult[4];

extern QueueHandle_t telem_motor_queue;

static float g_chassis_rot;

void movement_control_task(void *argument) {
	TickType_t start_time;
	//initialise in an array so it's possible to for-loop it later
	motor_yaw_mult[0] = FR_YAW_MULT;
	motor_yaw_mult[1] = FL_YAW_MULT;
	motor_yaw_mult[2] = BL_YAW_MULT;
	motor_yaw_mult[3] = BR_YAW_MULT;
	while (1) {

#ifndef CHASSIS_MCU

		EventBits_t motor_bits;
		//wait for all motors to have updated data before PID is allowed to run
		motor_bits = xEventGroupWaitBits(chassis_event_group, 0b1111, pdTRUE,
		pdTRUE,
		portMAX_DELAY);
		if (motor_bits == 0b1111) {
			status_led(3, on_led);
			start_time = xTaskGetTickCount();
			if (chassis_ctrl_data.enabled) {

#ifdef HALL_ZERO
			if (g_gimbal_state){
				hall_enable();
				while(hall_state == HALL_ON)
				yaw_zeroing(g_can_motors + FR_MOTOR_ID - 1,
						g_can_motors + FL_MOTOR_ID - 1,
						g_can_motors + BL_MOTOR_ID - 1,
						g_can_motors + BR_MOTOR_ID - 1);
			}
#endif
				chassis_motion_control(g_can_motors + FR_MOTOR_ID - 1,
						g_can_motors + FL_MOTOR_ID - 1,
						g_can_motors + BL_MOTOR_ID - 1,
						g_can_motors + BR_MOTOR_ID - 1);
			} else {
				g_can_motors[FR_MOTOR_ID - 1].output = 0;
				g_can_motors[FL_MOTOR_ID - 1].output = 0;
				g_can_motors[BL_MOTOR_ID - 1].output = 0;
				g_can_motors[BR_MOTOR_ID - 1].output = 0;

			}
#else
		chassis_MCU_send_CAN();
#endif
			status_led(3, off_led);
		} else {
			//motor timed out
			g_can_motors[FR_MOTOR_ID - 1].output = 0;
			g_can_motors[FL_MOTOR_ID - 1].output = 0;
			g_can_motors[BL_MOTOR_ID - 1].output = 0;
			g_can_motors[BR_MOTOR_ID - 1].output = 0;
		}
		//clear bits if it's not already cleared
		xEventGroupClearBits(chassis_event_group, 0b1111);
		//delays task for other tasks to run
		vTaskDelayUntil(&start_time, CHASSIS_DELAY);
	}
	osThreadTerminate(NULL);
}
void chassis_MCU_send_CAN() {

}
static uint32_t chassis_rpm_max = LV1_MAX_SPEED;


pid_data_t b_speed_pid;
pid_data_t b_angle_pid;

void b_pid_init(){
	b_speed_pid.kp = B_SPEED_KP;
	b_speed_pid.ki = B_SPEED_KI;
	b_speed_pid.kd = B_SPEED_KD;
	b_speed_pid.int_max = B_SPEED_INT_MAX;
	b_speed_pid.max_out = B_MAX_ANG;

	b_angle_pid.kp = B_ANGLE_KP;
	b_angle_pid.ki = B_ANGLE_KI;
	b_angle_pid.kd = B_ANGLE_KD;
	b_angle_pid.int_max = B_ANGLE_INT_MAX;
	b_angle_pid.max_out = B_MAX_CURRENT;
}

void chassis_motion_control(motor_data_t *motorfr, motor_data_t *motorfl,
		motor_data_t *motorbl, motor_data_t *motorbr) {
	//get target angle

	float vforwardrpm = (motorfr->raw_data.rpm * FR_VY_MULT
			+ motorfl->raw_data.rpm * FL_VY_MULT
			+ motorbl->raw_data.rpm * BL_VY_MULT
			+ motorbr->raw_data.rpm * BR_VY_MULT) / 4;
	float vforward = (vforwardrpm);
//	float vforward = (WHEEL_CIRC * vforwardrpm);

	float vhorizontalrpm = (motorfr->raw_data.rpm * FR_VX_MULT
			+ motorfl->raw_data.rpm * FL_VX_MULT
			+ motorbl->raw_data.rpm * BL_VX_MULT
			+ motorbr->raw_data.rpm * BR_VX_MULT) / 4;
	float vhorizontal = (vhorizontalrpm);
//	float vhorizontal = (WHEEL_CIRC * vhorizontalrpm);
	float vyawrpm = (motorfr->raw_data.rpm * FR_YAW_MULT
			+ motorfl->raw_data.rpm * FL_YAW_MULT
			+ motorbl->raw_data.rpm * BL_YAW_MULT
			+ motorbr->raw_data.rpm * BR_YAW_MULT) / 4;
	float vyaw = (vyawrpm);
//	float vyaw = (WHEEL_CIRC * vyawrpm);

	float rel_angle = g_can_motors[YAW_MOTOR_ID - 1].angle_data.adj_ang;
	float rel_forward = ((-chassis_ctrl_data.horizontal * sin(-rel_angle))
			+ (chassis_ctrl_data.forward * cos(-rel_angle))) * MAX_SPEED;
	float rel_horizontal = ((-chassis_ctrl_data.horizontal * cos(-rel_angle))
			+ (chassis_ctrl_data.forward * -sin(-rel_angle))) * MAX_SPEED;
	float rel_yaw = chassis_ctrl_data.yaw* MAX_YAW;

	speed_pid(rel_forward, vforward, &b_speed_pid);
	speed_pid(b_speed_pid.output, imu_heading.pit, &b_angle_pid);
	//filter forward rpm from pid calcs

	float filtered_rpm_fr = motorfr->raw_data.rpm - (vforwardrpm * FR_VY_MULT);
	float filtered_rpm_fl = motorfl->raw_data.rpm - (vforwardrpm * FL_VY_MULT);
	float filtered_rpm_bl = motorbl->raw_data.rpm - (vforwardrpm * BL_VY_MULT);
	float filtered_rpm_br = motorbr->raw_data.rpm - (vforwardrpm * BR_VY_MULT);

	float target_rpm_fr = rel_horizontal * FR_VX_MULT + rel_yaw * FR_YAW_MULT;
	float target_rpm_fl = rel_horizontal * FL_VX_MULT + rel_yaw * FL_YAW_MULT;
	float target_rpm_bl = rel_horizontal * BL_VX_MULT + rel_yaw * BL_YAW_MULT;
	float target_rpm_br = rel_horizontal * BR_VX_MULT + rel_yaw * BR_YAW_MULT;

	speed_pid(target_rpm_fr, filtered_rpm_fr, &motorfr->rpm_pid);
	speed_pid(target_rpm_fl, filtered_rpm_fl, &motorfl->rpm_pid);
	speed_pid(target_rpm_bl, filtered_rpm_bl, &motorbl->rpm_pid);
	speed_pid(target_rpm_br, filtered_rpm_br, &motorbr->rpm_pid);


	motorfr->output = motorfr->rpm_pid.output + (b_angle_pid.output * FR_VY_MULT);
	motorfl->output = motorfl->rpm_pid.output + (b_angle_pid.output * FL_VY_MULT);
	motorbl->output = motorbl->rpm_pid.output + (b_angle_pid.output * BL_VY_MULT);
	motorbr->output = motorbr->rpm_pid.output + (b_angle_pid.output * BR_VY_MULT);
}

