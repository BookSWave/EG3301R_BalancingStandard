/*
 * can_relay_task.c
 *
 *  Created on: 24 Jan 2022
 *      Author: wx
 */


void can_relay_task(void *argument)
{

}
