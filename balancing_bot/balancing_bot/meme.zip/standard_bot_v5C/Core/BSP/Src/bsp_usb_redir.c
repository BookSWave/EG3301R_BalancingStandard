/*
 * bsp_usb_redir.c
 *
 *  Created on: Dec 3, 2021
 *      Author: wx
 */
#include "cmsis_os.h"
#include "usbd_cdc_if.h"

//replaces the original _write function in stdio libraries

