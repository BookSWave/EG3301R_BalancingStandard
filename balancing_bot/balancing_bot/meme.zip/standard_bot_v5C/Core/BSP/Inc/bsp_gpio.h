/*
 * bsp_gpio.h
 *
 *  Created on: Sep 7, 2021
 *      Author: wx
 */

#ifndef BSP_INC_BSP_GPIO_H_
#define BSP_INC_BSP_GPIO_H_

void laser_on();
void laser_off();


#endif /* BSP_INC_BSP_GPIO_H_ */
