/*
 * bsp_hall.h
 *
 *  Created on: Mar 21, 2024
 *      Author: wx
 */

#ifndef BSP_INC_BSP_HALL_H_
#define BSP_INC_BSP_HALL_H_
void hall_int();


#endif /* BSP_INC_BSP_HALL_H_ */
