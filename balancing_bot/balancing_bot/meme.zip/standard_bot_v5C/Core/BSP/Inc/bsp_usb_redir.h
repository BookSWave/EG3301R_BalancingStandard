/*
 * bsp_usb_redir.h
 *
 *  Created on: Dec 3, 2021
 *      Author: wx
 */

#ifndef BSP_INC_BSP_USB_REDIR_H_
#define BSP_INC_BSP_USB_REDIR_H_
int _write(int file, char *ptr, int len);


#endif /* BSP_INC_BSP_USB_REDIR_H_ */
